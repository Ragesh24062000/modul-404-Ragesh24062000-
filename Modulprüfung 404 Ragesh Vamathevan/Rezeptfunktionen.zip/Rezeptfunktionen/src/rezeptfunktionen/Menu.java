/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rezeptfunktionen;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author rages
 */
public class Menu {

    protected Collection<MenuItem> items = new HashSet<MenuItem>();

    public void AddMenuItem(char key, String text, Menu.Funktion funct) {
        MenuItem item = new MenuItem(key, text, funct);
        items.add(item);
    }

    public Funktion getMenuItemFunktion(char key) {
        for (Iterator i = this.items.iterator(); i.hasNext();) {
            MenuItem item = (MenuItem) i.next();

            if (item.getKey() == key) {
                return item.getFunktion();
            }
        }
        return null;
    }

    public void Anzeigen() {
        char auswahl = ' ';

        for (int i = 0; i < 50; ++i) {
            System.out.println();
        }

        System.out.println("M e n u \n");

        for (Iterator i = this.items.iterator(); i.hasNext();) {
            System.out.println(i.next());
        }

        System.out.println("\n0   Beenden\n");

        System.out.println("Bitte waehlen ");

        auswahl = CLesen.readChar();

        if (auswahl == '0') {
            return;
        } else {
            this.getMenuItemFunktion(auswahl).eval();
            
            System.out.println("... bitte Taste drücken...");
            new java.util.Scanner(System.in).nextLine();
            
            this.Anzeigen();
        }
    }

    public interface Funktion {

        void eval();
    }

    private class MenuItem {

        protected char key;
        protected String text;
        protected Menu.Funktion funct;

        MenuItem() {
            this.key = '0';
            this.text = "";
            this.funct = null;
        }

        MenuItem(char key, String text, Menu.Funktion funct) {
            this.key = key;
            this.text = text;
            this.funct = funct;
        }

        @Override
        public String toString() {
            return this.key + "   " + this.text;
        }

        public char getKey() {
            return this.key;
        }

        public Funktion getFunktion() {
            return this.funct;
        }

        @Override
        public int hashCode() {
            int hash = 5;
            hash = 29 * hash + this.key;
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final MenuItem other = (MenuItem) obj;
            if (this.key != other.key) {
                return false;
            }
            return true;
        }
    }

}
