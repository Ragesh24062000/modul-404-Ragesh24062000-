/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rezeptfunktionen;

/**
 *
 * @author rages
 */
public class Rezeptfunktionen {

    /**
     */
    public static Rezepte dieRezepte;
    
    public static void main(String[] args) {
        // TODO code application logic here
        dieRezepte = Rezepte.readRezepte();
        
        Menu men1 = new Menu();
        men1.AddMenuItem('a', "Rezept zufügen", menAdd);
        men1.AddMenuItem('b', "Rezept ändern", menEdit);
        men1.AddMenuItem('c', "Rezept löschen", menDelete);
        men1.AddMenuItem('d', "Rezept ausgeben", menList);
        men1.Anzeigen();
        
        Rezepte.safeRezepte(dieRezepte);
    }

    public static final Menu.Funktion menAdd = new Menu.Funktion() {
        public void eval() {
            dieRezepte.addRezept();
            return;
        }
    };
    public static final Menu.Funktion menEdit = new Menu.Funktion() {
        public void eval() {
            dieRezepte.editRezept();
            return;
        }
    };
    public static final Menu.Funktion menList = new Menu.Funktion() {
        public void eval() {
            dieRezepte.listRezepte();
            return;
        }
    };
    public static final Menu.Funktion menDelete = new Menu.Funktion() {
        public void eval() {
            dieRezepte.deleteRezept();
            return;
        }
    };
}